<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario potenciación de números</title>
</head>
<body>

    <header>
        <h1>Formulario para potenciar números</h1>
    </header>

    <div>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
            <div id="inputControls">
                <input type="text" name="number1" id="number1" placeholder="Base a potenciar">
                <input type="text" name="number2" id="number2" placeholder="Potencia a elevar">
            </div>
            <div>
                <input type="submit" name="submitButton" id="submitButton" value="Calcular Operacion">
            </div>
        </form>
    </div>
    
</body>
</html>

<?php



if(isset($_POST['submitButton']) ? $_POST['submitButton'] : 0){
    $baseNumber = $_POST['number1'] ;
    $powNumber = $_POST['number2'];
    $resultado = 0;

    if(strlen($baseNumber) > 0 && strlen($powNumber) > 0){
        if(is_numeric($baseNumber) && is_numeric($powNumber)){
                    $i = 1;
                    $resultado = $baseNumber;
                    for($i; $i < $powNumber; $i++){
                        $resultado *= $baseNumber;
                        
                    }
                    echo "El resultado de ". $baseNumber . " ^ ". $powNumber . " es: ". $resultado;
                    
        }
    }else{
        echo "Llenar campos.";
    }
}


            
/*if(isset($submitButton)){
    if(is_numeric($baseNumber) && is_numeric($powNumber)){
        if(floatval($baseNumber) == true || intval(floatval($baseNumber)) == true){
            $floatVal = floatval($powNumber);
            if($floatVal && intval($floatVal) != $floatVal){
                $i = 0;
                $resultado = $baseNumber;
                while($i <= $powNumber){
                    $resultado *= $baseNumber;
                }//endwhile
                echo "El resultado de ". $baseNumber . " ^ ". $powNumber . " es: ". $resultado;
            }
        }
    }
}*/