<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingreso de Notas</title>
</head>
<body>
<header>
        <h1>Ingreso de Notas de Estudiantes</h1>
    </header>
    <div id="formDiv">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        <div id="firstStudent">
            <div>
                <label>Nombre de Alumno 1: </label>
                <input type="text" name="nameStudent1" id="nameStudent1">
            </div>
            <div>
                <label>Nota Parcial:  </label>
                <input type="text" name="notaParcial1" id="notaParcial1">
            </div>
            <div>
                <label>Nota Tarea: </label>
                <input type="text" name="notaTarea1" id="nameStudent1">
            </div>
            <div>
                <label>Nota Investigación: </label>
                <input type="text" name="notaInvestigacion1" id="notaInvestigacion1">
            </div>
        </div>
        <div id="secondStudent">
            <div>
                <label>Nombre de Alumno 2: </label>
                <input type="text" name="nameStudent2" id="nameStudent2">
            </div>
            <div>
                <label>Nota Parcial:  </label>
                <input type="text" name="notaParcial2" id="notaParcial2">
            </div>
            <div>
                <label>Nota Tarea: </label>
                <input type="text" name="notaTarea2" id="nameStudent2">
            </div>
            <div>
                <label>Nota Investigación: </label>
                <input type="text" name="notaInvestigacion2" id="notaInvestigacion2">
            </div>
        </div>
        <div id="thirdStudent">
            <div>
                <label>Nombre de Alumno 3: </label>
                <input type="text" name="nameStudent3" id="nameStudent3">
            </div>
            <div>
                <label>Nota Parcial:  </label>
                <input type="text" name="notaParcial3" id="notaParcia3">
            </div>
            <div>
                <label>Nota Tarea: </label>
                <input type="text" name="notaTarea3" id="nameStudent3">
            </div>
            <div>
                <label>Nota Investigación: </label>
                <input type="text" name="notaInvestigacion3" id="notaInvestigacion1">
            </div>
        </div>
        <input type="submit" name="submitB" id="submitB" value="Ingresar notas">
        </form>
    </div>
</body>
</html>

<?php


if(isset($_POST['submitB']) ? $_POST['submitB'] : 0){
    
    $resultado = "";
    $promedioParcial = 0;
    $promedioInvestigacion = 0;
    $promedioTarea = 0;
    $promedioGeneral = 0;

    $arrayOfNames = array($_POST['nameStudent1'], $_POST['nameStudent2'], $_POST['nameStudent3']);

    $notas = array(
        $arrayOfNames[0] => array(
            "Parcial" => $_POST['notaParcial1'],
            "Investigacion" => $_POST['notaInvestigacion1'],
            "Tarea" => $_POST['notaTarea1']
        ),
        $arrayOfNames[1] => array(
            "Parcial" => $_POST['notaParcial2'],
            "Investigacion" => $_POST['notaInvestigacion2'],
            "Tarea" => $_POST['notaTarea2']
        ),
        $arrayOfNames[2] => array(
            "Parcial" => $_POST['notaParcial3'],
            "Investigacion" => $_POST['notaInvestigacion3'],
            "Tarea" => $_POST['notaTarea3']
        )
        );
    foreach($notas as $alumnos){
        $resultado = "<table>";
        $resultado .= "<tr>";
        $resultado .= "<th>Alumno</th>";
        $resultado .= "<th>Actividad</th>";
        $resultado .= "<th>Nota</th>";
        $resultado .= "<th>Promedio</th>";
        $resultado .= "</tr>";
        
        foreach($alumnos as $key => $nota){
            $resultado .= "<tr>";
            $resultado .= "<td> Alumno </td>";

            switch($key){
                case "Parcial":
                    $promedioParcial = $nota * 0.80;
                    break;
                case "Investigacion":
                    $promedioInvestigacion = $nota * 0.70;
                    break;
                case "Tarea":
                    $promedioTarea = $nota * 0.50;
                    break;
                default:
                    $promedioGeneral = 0;
                break;
            }
            $promedioGeneral = ($promedioParcial + $promedioInvestigacion + $promedioTarea);
            $resultado .= "<td> ". $key . "</td>";
            $resultado .= "<td>" . $nota . "</td>";
        }
        $resultado .= "<td>" . $promedioGeneral . "</td>";
        $resultado .= "</tr>";
        $resultado .= "</table>";
        echo $resultado;
    }
   
    
}





?>