<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablas de multiplicar 1 - 10</title>
</head>
<body>
    <header>
        <h1>Tablas de multiplicar</h1>
    </header>
    <div id="formDiv">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <div>
                <label>Ingrese un numero del 1 al 10: </label>
                <input type="text" name="number" id="number" placeholder ="Numero de tablas a mostrar" maxlength="2">
            </div>
            <div>
                <input type="submit" name="submitB" id="submitB" value="Confirmar">
            </div>
        </form>
    </div>
    
</body>
</html>

<?php


if(isset($_POST['number']) ? $_POST['number'] : 0){
    $arrayForNumbers = [1,2,3,4,5,6,7,8,9,10];
    $number = $_POST['number'];
    if(strlen($number) > 0){
        $numeroEncontrado = array_search($number, $arrayForNumbers);
        if($numeroEncontrado){
            $numberMult = $arrayForNumbers[$numeroEncontrado];
            $result = 0;
            echo "<h1>Tabla de Multiplicar del número " . $numberMult . "</h1>";
            for($i = 0; $i < 11; $i++){
                $result = "<table>";
                $result .= "<tr>";
                $result .= "<td>" . $numberMult . "</td>";
                $result .= "<td> x </td>";
                $result .= "<td>" . $i . "</td>";
                $result .= "<td> = </td>";
                $result .= "<td>" . $numberMult * $i . "</td>";
                $result .= "</tr>";
                $result .= "</table>";
                echo $result;
            }
        }else{
            echo "<p id=\"error\">No hay tabla de multiplicar para ese numero</p>";
        }
    }else{
        echo "<p id=\"error\">Llena los campos</p>";
    }
}